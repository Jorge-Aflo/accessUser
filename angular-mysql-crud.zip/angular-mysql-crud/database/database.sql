CREATE DATABASE ACCESSUSERS_DB;

USE ACCESSUSERS_DB;

create table USERS (
	id int AUTO_INCREMENT primary key,
    username varchar(50),
    password varchar(50),
    firstName varchar(50),
    lastName varchar(50),
    token varchar(50)
);