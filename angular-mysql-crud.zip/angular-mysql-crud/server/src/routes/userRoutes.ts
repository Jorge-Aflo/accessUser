import { Router } from 'express';

import { userController }  from '../controllers/userController';

class UserRoutes {
    router: Router = Router();

    constructor(){
        this.config();
    }

    config(): void{
        this.router.get('/', userController.list);
        this.router.get('/:id', userController.getOnly);
        this.router.post('/', userController.create);
        this.router.delete('/:id', userController.delete);
        this.router.put('/:id', userController.update);
    }
}

export default new UserRoutes().router;