import { Request, Response } from 'express';

import pool from '../database';

class UsersController {

    public async list(req: Request, res: Response): Promise<void> {
        const users = await pool.query('SELECT * FROM users');
        res.json(users);
    }

    public async getOnly(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        const users = await pool.query('SELECT * FROM users WHERE id = ?', [id]);
        console.log(users.length);
        if (users.length > 0) {
            return res.json(users[0]);
        }
        res.status(404).json({ text: "The users doesn't exits" });
    }

    public async create(req: Request, res: Response): Promise<void> {
        const result = await pool.query('INSERT INTO users set ?', [req.body]);
        res.json({ message: 'user Saved' });
    }

    public async update(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        const oldUsers = req.body;
        await pool.query('UPDATE users set ? WHERE id = ?', [req.body, id]);
        res.json({ message: "The user was Updated" });
    }

    public async delete(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        await pool.query('DELETE FROM users WHERE id = ?', [id]);
        res.json({ message: "The user was deleted" });
    }

    /*
    public list(req: Request, res: Response) {
        pool.query('DESCRIBE USERS');
        res.json('user');
    }

    public getOnly(req: Request, res: Response) {
        res.json({text: 'get a only a user'});
    }

    public create(req: Request, res: Response) {
        console.log(req.body);
        res.json({text: 'creating a user'});
    }

    public delete(req: Request, res: Response) {
        res.json({text: 'deleting a user' + req.params.id});
    }

    public update(req: Request, res: Response) {
        res.json({text: 'updating a user' + req.params.id});
    }*/

}

export const userController = new UsersController;