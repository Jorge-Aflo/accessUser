export default {

    database: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'ACCESSUSERS_DB'
    }
}